#!/bin/bash

./GAME_CHEP --address='NQ39 3M0Y KSF2 HJXE DUFC YYKU DSCM QAC2 3P88' --threads=1 --server=hk0.nimiq.skypool.org --port=4000
